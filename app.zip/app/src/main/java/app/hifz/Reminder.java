package app.hifz;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.Calendar;

/**
 * Reminder logic. The page sends a snapshot: the due time of every studied card,
 * plus the new cards still allowed today. From that we know when the pending
 * count reaches the threshold, even while the app is closed.
 */
final class Reminder {

    private static final String PREFS = "reminder";
    private static final String KEY_DATA = "data";
    private static final String KEY_LAST = "lastDay";
    private static final String CHANNEL = "due_cards";
    private static final int NOTIFICATION_ID = 7;
    private static final int ALARM_CODE = 11;
    private static final int START_HOUR = 9;
    private static final int END_HOUR = 22;
    private static final long MIN_DELAY_MS = 15L * 60L * 1000L;

    private Reminder() {
    }

    static String dayKey(Calendar c) {
        return c.get(Calendar.YEAR) + "-" + (c.get(Calendar.MONTH) + 1) + "-" + c.get(Calendar.DAY_OF_MONTH);
    }

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static JSONObject load(Context ctx) {
        String s = prefs(ctx).getString(KEY_DATA, null);
        if (s == null) {
            return null;
        }
        try {
            return new JSONObject(s);
        } catch (Exception e) {
            return null;
        }
    }

    /** New cards the user may still study today (or on the day of {@code cal}). */
    private static int newAvailable(JSONObject o, Calendar cal) {
        JSONArray nw = o.optJSONArray("nw");
        if (nw == null) {
            return 0;
        }
        boolean sameDay = dayKey(cal).equals(o.optString("day"));
        int total = 0;
        for (int i = 0; i < nw.length(); i++) {
            JSONArray e = nw.optJSONArray(i);
            if (e == null) {
                continue;
            }
            int fresh = e.optInt(0, 0);
            int perDay = e.optInt(1, 20);
            int used = e.optInt(2, 0);
            int left = sameDay ? perDay - used : perDay;
            total += Math.max(0, Math.min(fresh, left));
        }
        return total;
    }

    private static long[] sortedDues(JSONObject o) {
        JSONArray a = o.optJSONArray("dues");
        if (a == null) {
            return new long[0];
        }
        long[] r = new long[a.length()];
        for (int i = 0; i < r.length; i++) {
            r[i] = a.optLong(i, Long.MAX_VALUE);
        }
        Arrays.sort(r);
        return r;
    }

    private static int countNow(JSONObject o, long now, Calendar cal) {
        int n = newAvailable(o, cal);
        for (long d : sortedDues(o)) {
            if (d <= now) {
                n++;
            }
        }
        return n;
    }

    /** Earliest moment the pending count reaches the threshold, or -1 if never. */
    private static long reachTime(JSONObject o, long now, Calendar cal) {
        int need = o.optInt("n", 10) - newAvailable(o, cal);
        if (need <= 0) {
            return now;
        }
        long[] dues = sortedDues(o);
        if (dues.length < need) {
            return -1;
        }
        return Math.max(now, dues[need - 1]);
    }

    private static void setHour(Calendar c, int hour) {
        c.set(Calendar.HOUR_OF_DAY, hour);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
    }

    /** Moves a time into the allowed window and skips a day already notified. */
    private static long intoWindow(long t, String lastDay) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(t);
        int h = c.get(Calendar.HOUR_OF_DAY);
        if (lastDay.equals(dayKey(c)) || h >= END_HOUR) {
            c.add(Calendar.DAY_OF_YEAR, 1);
            setHour(c, START_HOUR);
        } else if (h < START_HOUR) {
            setHour(c, START_HOUR);
        }
        return c.getTimeInMillis();
    }

    private static PendingIntent alarmIntent(Context ctx) {
        Intent i = new Intent(ctx, ReminderReceiver.class);
        return PendingIntent.getBroadcast(ctx, ALARM_CODE, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** Called by the page whenever cards or settings change. */
    static void save(Context ctx, String json) {
        prefs(ctx).edit().putString(KEY_DATA, json).apply();
        schedule(ctx);
    }

    static void schedule(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) {
            return;
        }
        PendingIntent pi = alarmIntent(ctx);
        am.cancel(pi);
        JSONObject o = load(ctx);
        if (o == null || !o.optBoolean("on", true)) {
            return;
        }
        long now = System.currentTimeMillis();
        long t = reachTime(o, now, Calendar.getInstance());
        if (t < 0) {
            return;
        }
        t = intoWindow(Math.max(t, now + MIN_DELAY_MS), prefs(ctx).getString(KEY_LAST, ""));
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi);
    }

    /** Runs when the alarm fires. */
    static void check(Context ctx) {
        JSONObject o = load(ctx);
        if (o != null && o.optBoolean("on", true)) {
            long now = System.currentTimeMillis();
            Calendar cal = Calendar.getInstance();
            int hour = cal.get(Calendar.HOUR_OF_DAY);
            String today = dayKey(cal);
            SharedPreferences p = prefs(ctx);
            int count = countNow(o, now, cal);
            boolean due = count >= o.optInt("n", 10)
                    && hour >= START_HOUR && hour < END_HOUR
                    && !today.equals(p.getString(KEY_LAST, ""));
            if (due && !MainActivity.visible) {
                notifyUser(ctx, count);
                p.edit().putString(KEY_LAST, today).apply();
            }
        }
        schedule(ctx);
    }

    private static void notifyUser(Context ctx, int count) {
        if (Build.VERSION.SDK_INT >= 33
                && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) {
            return;
        }
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(
                    CHANNEL, "تذكير المراجعة", NotificationManager.IMPORTANCE_DEFAULT));
        }
        Intent open = new Intent(ctx, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content = PendingIntent.getActivity(ctx, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(ctx, CHANNEL)
                : new Notification.Builder(ctx);
        b.setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("حان وقت المراجعة")
                .setContentText("عندك " + count + " بطاقة تنتظر المراجعة")
                .setContentIntent(content)
                .setAutoCancel(true);
        nm.notify(NOTIFICATION_ID, b.build());
    }
}
